package concesionario;

abstract class Vehiculo {
	
	protected String matricula;
	protected int añoFab;
	protected String conductor;
	
	public Vehiculo (String matricula, int anyoFab, String conductor.getNIF()) {
		
		this.matricula = matricula;
		this.añoFab = añoFab;
		this.conductor = conductor;
		
		System.out.println(this.matricula + this.añoFab +this.conductor);
		
	}
	
	

}
